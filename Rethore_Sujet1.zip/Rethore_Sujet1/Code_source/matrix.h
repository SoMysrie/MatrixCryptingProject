
void     choiceMatrix            (int *choice);
void    displayMatrix           (int tab[4][4]);
void    askMatrix               (int tab[4][4]);
int     verifMatrixNull         (int tab[4][4]);
int     verifMatrixDuplicate    (int tab[4][4]);
void    displayGenerator        (int tab1[4][4], int tab2[4][4], int tab3[4][8]);
void    productMatrix           (int tab1[4][4], int tab2[4][4], int tab3[4][8]);
