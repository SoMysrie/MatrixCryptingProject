
int     choiceMatrix        (int *choice);
int     calculInGenerator   (int tab1[4][4], int tab2[4][4], int tab3[4][8]);
int     calculOutGenerator  (int tab1[4][4], int tab2[4][4], int tab3[4][8]);
