
void    choiceFile      (int *choice);
void    choiceAgain     (int *choice);
int     *calculBin      (char d);
int     calculOct       (int *tab);
