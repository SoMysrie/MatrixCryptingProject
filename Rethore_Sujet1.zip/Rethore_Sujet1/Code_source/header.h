#ifndef HEADER
#define HEADER

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <conio.h>

#include "matrix.h"
#include "file.h"

#endif // HEADER
